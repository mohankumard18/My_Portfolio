export default {
  logoUrl: "https://placehold.co/256x256/07101f/5de4ff.png?text=MK"
};
