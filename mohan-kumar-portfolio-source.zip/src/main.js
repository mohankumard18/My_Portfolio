import './styles.css';

const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

const revealItems = document.querySelectorAll('.reveal');
if (prefersReducedMotion) {
  revealItems.forEach((item) => item.classList.add('is-visible'));
} else {
  const revealObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) return;
      entry.target.classList.add('is-visible');
      observer.unobserve(entry.target);
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -40px' });
  revealItems.forEach((item) => revealObserver.observe(item));
}

const mobileMenu = document.querySelector('#mobile-menu');
const menuToggle = document.querySelector('.menu-toggle');
const closeMenu = () => {
  mobileMenu?.classList.remove('open');
  mobileMenu?.setAttribute('aria-hidden', 'true');
  menuToggle?.setAttribute('aria-expanded', 'false');
  menuToggle?.setAttribute('aria-label', 'Open navigation');
};
menuToggle?.addEventListener('click', () => {
  const willOpen = !mobileMenu.classList.contains('open');
  mobileMenu.classList.toggle('open', willOpen);
  mobileMenu.setAttribute('aria-hidden', String(!willOpen));
  menuToggle.setAttribute('aria-expanded', String(willOpen));
  menuToggle.setAttribute('aria-label', willOpen ? 'Close navigation' : 'Open navigation');
});
mobileMenu?.querySelectorAll('a').forEach((link) => link.addEventListener('click', closeMenu));

const navLinks = [...document.querySelectorAll('.main-nav a')];
const navTargets = navLinks.map((link) => document.querySelector(link.getAttribute('href'))).filter(Boolean);
const activeObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (!entry.isIntersecting) return;
    navLinks.forEach((link) => link.removeAttribute('aria-current'));
    const active = navLinks.find((link) => link.getAttribute('href') === `#${entry.target.id}`);
    active?.setAttribute('aria-current', 'page');
  });
}, { threshold: 0.25, rootMargin: '-20% 0px -60% 0px' });
navTargets.forEach((target) => activeObserver.observe(target));

document.querySelector('#year').textContent = new Date().getFullYear();

const toast = document.querySelector('.toast');
let toastTimer;
document.querySelector('.copy-email')?.addEventListener('click', async (event) => {
  const email = event.currentTarget.dataset.copy;
  try {
    await navigator.clipboard.writeText(email);
    toast?.classList.add('show');
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => toast?.classList.remove('show'), 2200);
  } catch {
    window.location.href = `mailto:${email}`;
  }
});
