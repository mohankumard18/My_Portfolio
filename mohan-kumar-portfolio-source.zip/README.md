# Mohan Kumar Portfolio

A recruiter-focused single-page portfolio for Duppada Mohan Kumar, positioned for Data Analyst, Python Full Stack Developer, and Generative AI roles. Built with Vite, semantic HTML, vanilla JavaScript, and modular CSS.

## Run locally

```bash
npm install
npm run dev
```

Open `http://localhost:3000`.

## Production build

```bash
npm run build
```

The production output is written to `dist/`.

## Push to GitHub

```bash
git init
git add .
git commit -m "Create Mohan Kumar portfolio"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY.git
git push -u origin main
```

Replace the remote URL with your own GitHub repository. The supplied portrait is bundled locally at `public/mohan-profile.png`, and the resume download is at `public/Mohan_Kumar_Resume.pdf`.
