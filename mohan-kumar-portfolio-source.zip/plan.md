# Mohan Kumar Portfolio — Implementation & Design

## Product direction
A recruiter-first single-page portfolio that feels like a personal product landing page: precise, fast to scan, and clearly authored by an engineer rather than assembled from a generic theme.

## Design system
- **Design movement:** Neo-editorial developer portfolio with glass-panel depth, blueprint grid texture, and electric cyan signal accents.
- **Core principles:** recruiter clarity, evidence over decoration, premium restraint, and motion with intent.
- **Color philosophy:** deep ink/navy backgrounds communicate technical depth and confidence; cobalt and electric cyan highlight interactive states and data signals; muted steel text keeps long-form resume content comfortable to scan.
- **Layout paradigm:** asymmetric editorial flow: a command-style hero, sticky section rail, offset timeline, and horizontal project story cards rather than centered repeated grids.
- **Signature elements:** cyan vertical signal rail, small uppercase metadata labels, and soft blueprint-line background textures.
- **Interaction philosophy:** navigation and hover states behave like an instrument panel: clear feedback, quick transitions, no ornamental noise.
- **Animation:** hero items rise in on load; scroll reveals use short staggered opacity/translate transitions; project cards have restrained lift and cyan edge glow; timeline nodes pulse only on hover; all motion is disabled or reduced under `prefers-reduced-motion`.
- **Typography system:** Space Grotesk for display and navigation, IBM Plex Mono for metadata, labels, and code-like accents; high contrast hierarchy with compact uppercase eyebrow text.
- **Brand essence:** “A full-stack builder who turns messy developer and operational data into dependable products.” Personality: analytical, hands-on, composed.
- **Brand voice:** direct, evidence-led, quietly ambitious. Example lines: “I build the layer between data and decisions.” / “Let’s make your next product easier to trust.”
- **Wordmark & logo:** MK monogram inside a split-corner signal frame, paired with a compact `MOHAN.K` wordmark.
- **Signature brand color:** Electric cyan `#5DE4FF`, used sparingly for focus states and data-like highlights.

## Implementation
- Vite-powered static frontend with semantic HTML, modular CSS, and lightweight vanilla JavaScript.
- `src/main.js` owns navigation state, reveal observers, copy-email feedback, current-year output, and reduced-motion-aware interactions.
- `src/styles.css` owns the theme, responsive layout, panel system, animation, and accessibility states.
- `public/mohan-avatar.png` is the generated transparent avatar asset; `public/Mohan_Kumar_Resume.pdf` is the resume download.
- `public/manus-routes.json` declares the `/` page for Webdev.
- Static build configured with Vite for preview and publication.
